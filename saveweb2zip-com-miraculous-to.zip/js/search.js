(function () {
  'use strict';

  var modal = document.getElementById('mtoSearchModal');
  var trigger = document.getElementById('mtoSearchTrigger');
  var configNode = document.getElementById('mtoSearchConfig');
  if (!modal || !trigger || !configNode) return;

  var config;
  try {
    config = JSON.parse(configNode.textContent || '{}');
  } catch (error) {
    return;
  }

  var dialog = modal.querySelector('.mto-search-dialog');
  var closeButtons = modal.querySelectorAll('[data-search-close]');
  var input = document.getElementById('mtoSearchInput');
  var language = document.getElementById('mtoSearchLanguage');
  var results = document.getElementById('mtoSearchResults');
  var resultsWrap = modal.querySelector('.mto-search-results-wrap');
  var feedback = document.getElementById('mtoSearchFeedback');
  var loading = document.getElementById('mtoSearchLoading');
  var loadMore = document.getElementById('mtoSearchLoadMore');

  if (!dialog || !input || !language || !results || !feedback || !loading || !loadMore) return;

  var state = {
    timer: null,
    controller: null,
    requestId: 0,
    page: 1,
    lastFocused: null,
    sessionPromise: null,
    sessionReady: false
  };

  function copy(key) {
    return String((config.messages && config.messages[key]) || '');
  }

  function setFeedback(message, isError) {
    feedback.textContent = message;
    feedback.classList.toggle('is-error', Boolean(isError));
  }

  function setLoading(active) {
    loading.hidden = !active;
    results.setAttribute('aria-busy', active ? 'true' : 'false');
    loadMore.disabled = active;
  }

  function responseError(payload, fallbackCode) {
    var code = payload && payload.error ? payload.error.code : fallbackCode;
    var error = new Error(code);
    error.code = code;
    return error;
  }

  async function ensureSearchSession(force) {
    if (state.sessionReady && !force) return;
    if (state.sessionPromise) return state.sessionPromise;

    state.sessionPromise = (async function () {
      var response = await fetch(config.sessionEndpoint, {
        method: 'POST',
        credentials: 'same-origin',
        cache: 'no-store',
        headers: { 'Accept': 'application/json' }
      });

      var payload;
      try {
        payload = await response.json();
      } catch (parseError) {
        payload = null;
      }

      if (!response.ok || !payload || !payload.session) {
        state.sessionReady = false;
        throw responseError(payload, 'session_unavailable');
      }

      state.sessionReady = true;
    }());

    try {
      return await state.sessionPromise;
    } finally {
      state.sessionPromise = null;
    }
  }

  async function sendSearchRequest(body, signal) {
    var response = await fetch(config.endpoint, {
      method: 'POST',
      credentials: 'same-origin',
      cache: 'no-store',
      headers: {
        'Accept': 'application/json',
        'Content-Type': 'application/x-www-form-urlencoded;charset=UTF-8'
      },
      body: body.toString(),
      signal: signal
    });

    var payload;
    try {
      payload = await response.json();
    } catch (parseError) {
      payload = null;
    }

    return { response: response, payload: payload };
  }

  function safeResultUrl(value) {
    try {
      var url = new URL(String(value || ''), window.location.origin);
      return url.origin === window.location.origin ? url.href : null;
    } catch (error) {
      return null;
    }
  }

  function clearResults() {
    results.replaceChildren();
    loadMore.hidden = true;
  }

  function createResultCard(item) {
    var href = safeResultUrl(item && item.url);
    if (!href) return null;

    var listItem = document.createElement('li');
    var card = document.createElement('a');
    card.className = 'mto-search-card';
    card.href = href;

    var image = document.createElement('img');
    image.className = 'mto-search-image';
    image.src = String(item.epimgurl || config.defaultImage || '');
    image.alt = '';
    image.loading = 'lazy';
    image.decoding = 'async';
    image.referrerPolicy = 'no-referrer';
    image.addEventListener('error', function () {
      if (image.src !== new URL(config.defaultImage, window.location.origin).href) {
        image.src = config.defaultImage;
      }
    }, { once: true });

    var body = document.createElement('div');
    body.className = 'mto-search-card-body';

    var title = document.createElement('h3');
    title.className = 'mto-search-card-title';
    title.textContent = String(item.eptitle || item.epcode || '');
    body.appendChild(title);

    if (item.epdesc) {
      var description = document.createElement('p');
      description.className = 'mto-search-description';
      description.textContent = String(item.epdesc);
      body.appendChild(description);
    }

    var meta = document.createElement('div');
    meta.className = 'mto-search-meta';
    var code = document.createElement('span');
    code.textContent = copy('episode') + ': ' + String(item.epcode || '');
    var badge = document.createElement('span');
    badge.className = 'mto-search-lang-badge';
    badge.textContent = String(item.eplang || '');
    meta.append(code, badge);
    body.appendChild(meta);

    card.append(image, body);
    listItem.appendChild(card);
    return listItem;
  }

  function renderItems(items, append) {
    if (!append) clearResults();
    var fragment = document.createDocumentFragment();
    items.forEach(function (item) {
      var card = createResultCard(item);
      if (card) fragment.appendChild(card);
    });
    results.appendChild(fragment);
  }

  async function performSearch(append) {
    var query = input.value.trim();
    if (query.length < 2) {
      if (!append) {
        clearResults();
        setFeedback(copy('initial'), false);
      }
      return;
    }

    if (state.controller) state.controller.abort();
    state.controller = new AbortController();
    state.requestId += 1;
    var requestId = state.requestId;
    var requestedPage = append ? state.page + 1 : 1;

    setLoading(true);
    setFeedback('', false);
    var body = new URLSearchParams({
      query: query,
      lang: language.value,
      page: String(requestedPage)
    });

    try {
      await ensureSearchSession(false);
      var searchResponse = await sendSearchRequest(body, state.controller.signal);
      var response = searchResponse.response;
      var payload = searchResponse.payload;

      if (response.status === 401 && payload && payload.error
          && payload.error.code === 'search_session_required') {
        state.sessionReady = false;
        await ensureSearchSession(true);
        searchResponse = await sendSearchRequest(body, state.controller.signal);
        response = searchResponse.response;
        payload = searchResponse.payload;
      }

      if (!response.ok || !payload) {
        throw responseError(payload, 'request_failed');
      }

      if (requestId !== state.requestId) return;
      var items = Array.isArray(payload.items) ? payload.items : [];
      renderItems(items, append);
      state.page = requestedPage;

      var hasMore = Boolean(payload.pagination && payload.pagination.has_more);
      loadMore.hidden = !hasMore;
      if (!append && items.length === 0) {
        setFeedback(copy('no_results'), false);
      } else {
        setFeedback('', false);
      }
      if (append && resultsWrap) resultsWrap.focus({ preventScroll: true });
    } catch (error) {
      if (error.name === 'AbortError' || requestId !== state.requestId) return;
      if (!append) clearResults();
      var message = error.code === 'rate_limited' ? copy('rate_limited') : copy('error');
      setFeedback(message, true);
    } finally {
      if (requestId === state.requestId) setLoading(false);
    }
  }

  function cancelPending() {
    if (state.timer) window.clearTimeout(state.timer);
    state.timer = null;
    state.requestId += 1;
    if (state.controller) state.controller.abort();
    state.controller = null;
    setLoading(false);
  }

  function openSearch() {
    state.lastFocused = document.activeElement;
    modal.hidden = false;
    trigger.setAttribute('aria-expanded', 'true');
    document.documentElement.classList.add('mto-search-open');
    document.body.classList.add('mto-search-open');
    setFeedback(copy('initial'), false);
    ensureSearchSession(false).catch(function (error) {
      var message = error.code === 'rate_limited' ? copy('rate_limited') : copy('error');
      setFeedback(message, true);
    });
    window.requestAnimationFrame(function () { input.focus(); });
  }

  function closeSearch() {
    cancelPending();
    modal.hidden = true;
    trigger.setAttribute('aria-expanded', 'false');
    document.documentElement.classList.remove('mto-search-open');
    document.body.classList.remove('mto-search-open');
    input.value = '';
    state.page = 1;
    clearResults();
    setFeedback(copy('initial'), false);
    if (state.lastFocused && typeof state.lastFocused.focus === 'function') {
      state.lastFocused.focus();
    } else {
      trigger.focus();
    }
  }

  function trapFocus(event) {
    if (event.key !== 'Tab') return;
    var focusable = Array.prototype.slice.call(dialog.querySelectorAll(
      'a[href], button:not([disabled]), input:not([disabled]), select:not([disabled]), [tabindex]:not([tabindex="-1"])'
    )).filter(function (element) { return !element.hidden; });
    if (!focusable.length) return;
    var first = focusable[0];
    var last = focusable[focusable.length - 1];
    if (event.shiftKey && document.activeElement === first) {
      event.preventDefault();
      last.focus();
    } else if (!event.shiftKey && document.activeElement === last) {
      event.preventDefault();
      first.focus();
    }
  }

  trigger.addEventListener('click', openSearch);
  closeButtons.forEach(function (button) {
    button.addEventListener('click', closeSearch);
  });
  modal.addEventListener('keydown', function (event) {
    if (event.key === 'Escape') {
      event.preventDefault();
      closeSearch();
      return;
    }
    trapFocus(event);
  });

  input.addEventListener('input', function () {
    cancelPending();
    state.page = 1;
    clearResults();
    var query = input.value.trim();
    if (query.length < 2) {
      setFeedback(copy('initial'), false);
      return;
    }
    state.timer = window.setTimeout(function () { performSearch(false); }, 350);
  });

  language.addEventListener('change', function () {
    cancelPending();
    state.page = 1;
    if (input.value.trim().length >= 2) performSearch(false);
  });
  loadMore.addEventListener('click', function () { performSearch(true); });
}());
